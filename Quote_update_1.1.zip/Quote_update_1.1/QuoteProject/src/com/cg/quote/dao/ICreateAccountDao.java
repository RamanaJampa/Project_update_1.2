package com.cg.quote.dao;

import java.io.IOException;

import com.cg.quote.bean.CreateAccount;
import com.cg.quote.bean.NewPolicySchemeBean;

public interface ICreateAccountDao {
	
	public void createAccount(CreateAccount createbean) throws IOException;

	public void createNewScheme(NewPolicySchemeBean newPolicySchemeBean) throws IOException;

}
